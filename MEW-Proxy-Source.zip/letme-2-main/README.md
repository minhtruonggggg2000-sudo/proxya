# MEW Proxy — Safe iOS Source

This is a rebranded safe build of the supplied SwiftUI project. The dashboard layout, device information, settings, ordinary file-management views, wallpaper tools, cache-cleaner UI, and app-launch shortcut are retained where supported by standard iOS permissions.

## Safety scope

- Gameplay patch activation is disabled. The original cards remain visible and clearly report that patching is unavailable in this safe build.
- Kernel exploit and sandbox-escape entry points are stubbed and cannot run.
- DevicePatchService refuses all patch writes/restores.
- The app does not claim that aim, antenna, magic, or FPS patches have been applied.

## Build

Open `ThreeOneOSFive.xcodeproj` in Xcode on macOS, select the `OGIOS` scheme, choose an iOS device or generic iOS destination, and build. The installed app display name is **MEW Proxy**. Signing with a valid Apple development team is required for installation on a physical iPhone.

This source has not been compiled or device-tested in this environment.
