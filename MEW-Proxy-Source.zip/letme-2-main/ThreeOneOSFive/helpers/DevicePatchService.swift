import Foundation

/// Safe MEW Proxy build: patch packages may be browsed and managed as files,
/// but this app does not write modifications into other apps' containers.
enum DevicePatchService {
    enum SafeBuildError: LocalizedError {
        case unavailable
        var errorDescription: String? {
            "Applying gameplay or system patches is disabled in this safe MEW Proxy build."
        }
    }

    static func apply(project: PatchProject) throws -> PatchTransactionReceipt {
        throw SafeBuildError.unavailable
    }

    static func restore(receipt: PatchTransactionReceipt) throws {
        throw SafeBuildError.unavailable
    }

    static func latestReceipt(projectID: UUID) -> PatchTransactionReceipt? {
        nil
    }
}
